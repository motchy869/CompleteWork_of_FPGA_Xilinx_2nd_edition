#include <cstdlib>
#include <xil_printf.h>
#include <xparameters.h>
#include <xavg_min_max.h>
#include <ap_fixed.h>

/**
 * @brief Print formatted string in Vitis serial console via vsnprintf.
 * Floating point number is supported.
 *
 * @tparam N the temporary buffer size
 * @param[in] format
 * @param[in] ...
 */
template <size_t N=256>
void xil_printf_ext(const char *format, ...) {
    char buf[N];
    va_list args;
    va_start (args, format);
    vsnprintf(buf, N, format, args);
    va_end(args);
    xil_printf("%s", buf);
}

typedef ap_fixed<16, 14, AP_RND_INF> q16p2_t;

template <typename T_FixedPoint, typename T_float>
T_float integerFixedPointValToFloat(const T_FixedPoint val) {
    return static_cast<T_float>(val) / static_cast<T_float>(1 << (T_FixedPoint::width - T_FixedPoint::iwidth));
}

constexpr size_t AVG_MIN_MAX_ARRAY_LENGTH = 16;

XAvg_min_max avg_min_maxInstance;

int main() {
    q16p2_t a[AVG_MIN_MAX_ARRAY_LENGTH];
    q16p2_t avg_expected, min_expected = 0, max_expected = 0;

    /* Initialize avg_min_max. */
    if (XAvg_min_max_Initialize(&avg_min_maxInstance, XPAR_AVG_MIN_MAX_0_DEVICE_ID) != XST_SUCCESS) {
        xil_printf_ext<256>("Error: avg_min_max failed to initialize.\n");
        return XST_FAILURE;
    }

    /* Create the expected result. */
    {
        q16p2_t sum;
        a[0] = 0.25*0; sum = a[0]; min_expected = sum; max_expected = sum;
        xil_printf_ext<256>("a[ 0]=%g\n", static_cast<float>(a[0]));
        for (size_t i=1; i<AVG_MIN_MAX_ARRAY_LENGTH; i++) {
            a[i] = 0.25*i;
            sum += a[i];
            if (a[i] < min_expected) {
                min_expected = a[i];
            }
            if (a[i] > max_expected) {
                max_expected = a[i];
            }
            xil_printf_ext<256>("a[%2ld]=%g\n", i, static_cast<float>(a[i]));
        }
        avg_expected = sum / AVG_MIN_MAX_ARRAY_LENGTH;
    }

    /* Write arrays a and b via AXI ports. */
    XAvg_min_max_Write_a_Words(&avg_min_maxInstance, 0, reinterpret_cast<uint32_t *>(&a[0]), AVG_MIN_MAX_ARRAY_LENGTH*sizeof(q16p2_t)/sizeof(uint32_t));

    /* Start the computation module and wait until the result is available */
    XAvg_min_max_Start(&avg_min_maxInstance);
    while (!XAvg_min_max_IsDone(&avg_min_maxInstance)) {};

    /* Compare the result with the expected one. */
    {
        const q16p2_t avg = integerFixedPointValToFloat<q16p2_t, float>(XAvg_min_max_Get_avg(&avg_min_maxInstance));
        const q16p2_t min = integerFixedPointValToFloat<q16p2_t, float>(XAvg_min_max_Get_min(&avg_min_maxInstance));
        const q16p2_t max = integerFixedPointValToFloat<q16p2_t, float>(XAvg_min_max_Get_max(&avg_min_maxInstance));
        if (avg == avg_expected && min == min_expected && max == max_expected) {
            xil_printf_ext<256>("OK.\n");
        } else {
            xil_printf_ext<256>("NG: avg = %d, min = %d, max = %d, avg_expected = %d, min_expected = %d, max_expected = %d\n", static_cast<uint16_t>(avg), static_cast<uint16_t>(min), static_cast<uint16_t>(max), static_cast<uint16_t>(avg_expected), static_cast<uint16_t>(min_expected), static_cast<uint16_t>(max_expected));
        }
    }

    return XST_SUCCESS;
}
