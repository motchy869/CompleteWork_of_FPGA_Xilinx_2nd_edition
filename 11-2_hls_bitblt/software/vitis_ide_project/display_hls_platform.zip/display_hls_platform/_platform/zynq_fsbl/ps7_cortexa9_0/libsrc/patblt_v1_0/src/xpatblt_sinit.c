// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2023.1.1 (64-bit)
// Tool Version Limit: 2023.06
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2023 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
#ifndef __linux__

#include "xstatus.h"
#include "xparameters.h"
#include "xpatblt.h"

extern XPatblt_Config XPatblt_ConfigTable[];

XPatblt_Config *XPatblt_LookupConfig(u16 DeviceId) {
	XPatblt_Config *ConfigPtr = NULL;

	int Index;

	for (Index = 0; Index < XPAR_XPATBLT_NUM_INSTANCES; Index++) {
		if (XPatblt_ConfigTable[Index].DeviceId == DeviceId) {
			ConfigPtr = &XPatblt_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XPatblt_Initialize(XPatblt *InstancePtr, u16 DeviceId) {
	XPatblt_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XPatblt_LookupConfig(DeviceId);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XPatblt_CfgInitialize(InstancePtr, ConfigPtr);
}

#endif

