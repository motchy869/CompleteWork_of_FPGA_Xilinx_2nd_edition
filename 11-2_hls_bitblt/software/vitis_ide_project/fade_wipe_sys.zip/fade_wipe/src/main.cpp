#include <cstdio>
#include <cstdlib>

#include <sleep.h>
#include <vector>

#include <xbitblt.h>
#include <xgpio.h>
#include <xil_cache.h>
#include <xparameters.h>
#include <xpatblt.h>
#include <xsdps.h>

#include <ff.h>

/* GPIO channels */
#define DISP_ADDR 1
#define DISP_ON 2
#define VBLANK 1
#define CLR_VBLANK 2

constexpr int DISPLAY_WIDTH = 640;
constexpr int DISPLAY_HEIGHT = 480;
constexpr size_t VRAM_START_ADDR = 0x10000000;
constexpr size_t TEXTURE_START_ADDR = VRAM_START_ADDR + 0x0012c000;
// volatile uint32_t *const VRAM = reinterpret_cast<uint32_t *>(VRAM_START_ADDR);
// volatile uint32_t *const TEXTURE = reinterpret_cast<uint32_t *>(VRAM_START_ADDR + 0x0012c000);

constexpr size_t BOX_WIDTH = 320;
constexpr size_t BOX_HEIGHT = 240;

/* the start pixel offset of source and destination */
constexpr size_t PIXEL_OFFSET_SRC0 = 0;
constexpr size_t PIXEL_OFFSET_SRC1 = 320 + 0*DISPLAY_WIDTH;
constexpr size_t PIXEL_OFFSET_DST0 = 80 + 60*DISPLAY_WIDTH;
constexpr size_t PIXEL_OFFSET_DST1 = 240 + 180*DISPLAY_WIDTH;

XGpio gGpioAddrOn, gGpioBlank;
XBitblt gBitbltInstance;
XPatblt gPatbltInstance;

size_t page_no_to_mem_addr(const int pageNo) {
    return VRAM_START_ADDR + pageNo*DISPLAY_WIDTH*DISPLAY_HEIGHT*sizeof(uint32_t);
}

/* Wait VBLANK. */
void wait_vblank() {
    XGpio_DiscreteWrite(&gGpioBlank, CLR_VBLANK, 1);
    XGpio_DiscreteWrite(&gGpioBlank, CLR_VBLANK, 0);
    while (XGpio_DiscreteRead(&gGpioBlank, VBLANK) == 0);
}

void bitblt(const int src_in, const int dst_in, const int dst_out, const int alpha, const int width, const int height) {
    XBitblt_Set_src_in(&gBitbltInstance, src_in);
    XBitblt_Set_dst_in(&gBitbltInstance, dst_in);
    XBitblt_Set_dst_out(&gBitbltInstance, dst_out);
    XBitblt_Set_alpha(&gBitbltInstance, alpha);
    XBitblt_Set_width(&gBitbltInstance, width);
    XBitblt_Set_height(&gBitbltInstance, height);
    XBitblt_Start(&gBitbltInstance);
    while (!XBitblt_IsDone(&gBitbltInstance)){};
}

void patblt(const int dst_out, const int xpos, const int ypos, const int width, const int height, const int color) {
    XPatblt_Set_dst_out(&gPatbltInstance, dst_out);
    XPatblt_Set_xpos(&gPatbltInstance, xpos);
    XPatblt_Set_ypos(&gPatbltInstance, ypos);
    XPatblt_Set_width(&gPatbltInstance, width);
    XPatblt_Set_height(&gPatbltInstance, height);
    XPatblt_Set_color(&gPatbltInstance, color);
    XPatblt_Start(&gPatbltInstance);
    while (!XPatblt_IsDone(&gPatbltInstance)){};
}

/**
 * @brief Load an image from the SD card.
 *
 * @param[in] filePath the path to the image file
 * @param[in] width the width of the image
 * @param[in] height the height of the image
 * @param[out] vramBuffer The VRAM buffer to store the image. It can be offsetted to store the image at a different location.
 * @retval false success
 * @retval true failure
 */
bool loadImage(const char *filePath, const int width, const int height, uint32_t *const vramBuffer) {
    const size_t readChunkSize = width*3; // 1 row (3 bytes per pixel)

    FIL fil;
    FRESULT fRes;
    UINT numBytesRead;
    std::vector<uint8_t> buffer(readChunkSize);
    bool retCode = false;

    /* Open the file. */
    fRes = f_open(&fil, filePath, FA_READ);
    if (FR_OK != fRes) {
        xil_printf("Error(%d): f_open\n", fRes);
        retCode = true;
        goto RETURN_TO_CALLER;
    }

    /* Read the file. */
    for (int row=0; row<height; ++row) {
        /* Read one row from the file. */
        fRes = f_read(&fil, buffer.data(), readChunkSize, &numBytesRead);

        if (FR_OK != fRes) {
            xil_printf("Error(%d): f_read\n", fRes);
            retCode = true;
            goto CLOSE_FILE;
        }

        /* Copy to the VRAM buffer. */
        uint32_t *vramBuffer_rowPtr = &vramBuffer[row*width];
        uint8_t *buffer_rowPtr = buffer.data();
        for (int col=0; col<width; ++col) {
            *vramBuffer_rowPtr = (*buffer_rowPtr << 16) | (*(buffer_rowPtr+1) << 8) | *(buffer_rowPtr+2);
            buffer_rowPtr += 3;
            ++vramBuffer_rowPtr;
        }
    }

    CLOSE_FILE:
        /* Close the file. */
        fRes = f_close(&fil);
        if (FR_OK != fRes) {
            xil_printf("Error(%d): f_close\n", fRes);
            retCode = true;
        }

    RETURN_TO_CALLER:
        return retCode;
}

int main() {
    FATFS fatFs;

    /* Initialize AXI devices. */
    {
        int status;
        /* Initialize GPIO_0 (display address, display on/off). */
        status = XGpio_Initialize(&gGpioAddrOn, XPAR_GPIO_0_DEVICE_ID);
        if (XST_SUCCESS != status) {
            return XST_FAILURE;
        }
        XGpio_SetDataDirection(&gGpioAddrOn, DISP_ADDR, 0);
        XGpio_SetDataDirection(&gGpioAddrOn, DISP_ON, 0);

        /* Initialize GPIO_1 (VBLANK control). */
        status = XGpio_Initialize(&gGpioBlank, XPAR_GPIO_1_DEVICE_ID);
        if (XST_SUCCESS != status) {
            return XST_FAILURE;
        }
        XGpio_SetDataDirection(&gGpioBlank, VBLANK, 1);
        XGpio_SetDataDirection(&gGpioBlank, CLR_VBLANK, 0);

        /* Initialize bitblt. */
        status = XBitblt_Initialize(&gBitbltInstance, XPAR_XBITBLT_0_DEVICE_ID);
        if (XST_SUCCESS != status) {
            return XST_FAILURE;
        }

        /* Initialize patblt. */
        status = XPatblt_Initialize(&gPatbltInstance, XPAR_XPATBLT_0_DEVICE_ID);
        if (XST_SUCCESS != status) {
            return XST_FAILURE;
        }
    }

    /* Mount the SD card. */
    {
        const FRESULT fRes = f_mount(&fatFs, "0:/", 0);
        if (FR_OK != fRes) {
            xil_printf("Error(%d): f_mount\n", fRes);
            return XST_FAILURE;
        }
    }

    /* Load the images. */
    {
        const char *filePaths[] = {"imgs/1.raw", "imgs/2.raw"};
        const int numImages = sizeof(filePaths)/sizeof(filePaths[0]);
        for (int i=0; i<numImages; ++i) {
            if (loadImage(filePaths[i], DISPLAY_WIDTH, DISPLAY_HEIGHT, reinterpret_cast<uint32_t *>(page_no_to_mem_addr(2+i)))) {
                xil_printf("Error, failed to load image.");
                return XST_FAILURE;
            }
        }
        Xil_DCacheFlush();
    }

    /* Clear the display buffer. */
    patblt(page_no_to_mem_addr(0), 0, 0, DISPLAY_WIDTH, DISPLAY_HEIGHT, 0x00000000);

    /* Enable display. */
    int visiblePageNo = 0;
    wait_vblank();
    XGpio_DiscreteWrite(&gGpioAddrOn, DISP_ADDR, page_no_to_mem_addr(visiblePageNo));
    XGpio_DiscreteWrite(&gGpioAddrOn, DISP_ON, 1);

    while (true) {
        /* Repeat fade-in and fade-out 4 times. */
        for (int i=0; i<4; ++i) {
            for (int alpha=0; alpha<2*256; alpha+=4) {
                /* Draw on invisible page. */
                const int invisiblePageNo = (visiblePageNo + 1) & 1;
                const int alpha2 = (alpha < 256 ? alpha : 2*256-1-alpha);
                bitblt(page_no_to_mem_addr(2), page_no_to_mem_addr(3), page_no_to_mem_addr(invisiblePageNo), alpha2, DISPLAY_WIDTH, DISPLAY_HEIGHT);

                /* Flip the visible page. */
                wait_vblank();
                visiblePageNo = invisiblePageNo;
                XGpio_DiscreteWrite(&gGpioAddrOn, DISP_ADDR, page_no_to_mem_addr(visiblePageNo));
            }
        }

        /* Repeat horizontal wipe 4 times. */
        for (int i=0; i<4; ++i) {
            for (int cnt=0; cnt<2*DISPLAY_WIDTH; cnt += 4, visiblePageNo = (visiblePageNo + 1) & 1) {
                const int invisiblePageNo = (visiblePageNo + 1) & 1;
                const int x = (cnt < DISPLAY_WIDTH ? cnt : 2*DISPLAY_WIDTH - cnt);
                bitblt(page_no_to_mem_addr(2), page_no_to_mem_addr(3), page_no_to_mem_addr(invisiblePageNo), 255, x, DISPLAY_HEIGHT);
                bitblt(page_no_to_mem_addr(2), page_no_to_mem_addr(3)+x*sizeof(uint32_t), page_no_to_mem_addr(invisiblePageNo)+x*sizeof(uint32_t), 0, DISPLAY_WIDTH-x, DISPLAY_HEIGHT);

                /* Flip the visible page. */
                wait_vblank();
                visiblePageNo = invisiblePageNo;
                XGpio_DiscreteWrite(&gGpioAddrOn, DISP_ADDR, page_no_to_mem_addr(visiblePageNo));
            }
        }
    }

    /* Disable display. */
    wait_vblank();
    XGpio_DiscreteWrite(&gGpioAddrOn, DISP_ON, 0);
    return XST_SUCCESS;
}
