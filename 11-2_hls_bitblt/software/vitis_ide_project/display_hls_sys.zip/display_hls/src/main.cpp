#include <cstdio>
#include <cstdlib>
#include <sleep.h>
#include <xbitblt.h>
#include <xgpio.h>
#include <xil_cache.h>
#include <xparameters.h>
#include <xpatblt.h>

/* GPIO channels */
#define DISP_ADDR 1
#define DISP_ON 2
#define VBLANK 1
#define CLR_VBLANK 2

constexpr size_t DISPLAY_WIDTH = 640;
constexpr size_t DISPLAY_HEIGHT = 480;
constexpr size_t VRAM_START_ADDR = 0x10000000;
constexpr size_t TEXTURE_START_ADDR = VRAM_START_ADDR + 0x0012c000;
// volatile uint32_t *const VRAM = reinterpret_cast<uint32_t *>(VRAM_START_ADDR);
// volatile uint32_t *const TEXTURE = reinterpret_cast<uint32_t *>(VRAM_START_ADDR + 0x0012c000);

constexpr size_t BOX_WIDTH = 320;
constexpr size_t BOX_HEIGHT = 240;

/* the start pixel offset of source and destination */
constexpr size_t PIXEL_OFFSET_SRC0 = 0;
constexpr size_t PIXEL_OFFSET_SRC1 = 320 + 0*DISPLAY_WIDTH;
constexpr size_t PIXEL_OFFSET_DST0 = 80 + 60*DISPLAY_WIDTH;
constexpr size_t PIXEL_OFFSET_DST1 = 240 + 180*DISPLAY_WIDTH;

XGpio gGpioAddrOn, gGpioBlank;
XBitblt gBitbltInstance;
XPatblt gPatbltInstance;

/* Wait VBLANK. */
void wait_vblank() {
    XGpio_DiscreteWrite(&gGpioBlank, CLR_VBLANK, 1);
    XGpio_DiscreteWrite(&gGpioBlank, CLR_VBLANK, 0);
    while (XGpio_DiscreteRead(&gGpioBlank, VBLANK) == 0);
}

void bitblt(const int src_in, const int dst_in, const int dst_out, const int alpha, const int width, const int height) {
    XBitblt_Set_src_in(&gBitbltInstance, src_in);
    XBitblt_Set_dst_in(&gBitbltInstance, dst_in);
    XBitblt_Set_dst_out(&gBitbltInstance, dst_out);
    XBitblt_Set_alpha(&gBitbltInstance, alpha);
    XBitblt_Set_width(&gBitbltInstance, width);
    XBitblt_Set_height(&gBitbltInstance, height);
    XBitblt_Start(&gBitbltInstance);
    while (!XBitblt_IsDone(&gBitbltInstance)){};
}

void patblt(const int dst_out, const int xpos, const int ypos, const int width, const int height, const int color) {
    XPatblt_Set_dst_out(&gPatbltInstance, dst_out);
    XPatblt_Set_xpos(&gPatbltInstance, xpos);
    XPatblt_Set_ypos(&gPatbltInstance, ypos);
    XPatblt_Set_width(&gPatbltInstance, width);
    XPatblt_Set_height(&gPatbltInstance, height);
    XPatblt_Set_color(&gPatbltInstance, color);
    XPatblt_Start(&gPatbltInstance);
    while (!XPatblt_IsDone(&gPatbltInstance)){};
}

int main() {
    int status;

    /* Initialize GPIO_0 (display address, display on/off). */
    status = XGpio_Initialize(&gGpioAddrOn, XPAR_GPIO_0_DEVICE_ID);
    if (XST_SUCCESS != status) {
        return XST_FAILURE;
    }
    XGpio_SetDataDirection(&gGpioAddrOn, DISP_ADDR, 0);
    XGpio_SetDataDirection(&gGpioAddrOn, DISP_ON, 0);

    /* Initialize GPIO_1 (VBLANK control). */
    status = XGpio_Initialize(&gGpioBlank, XPAR_GPIO_1_DEVICE_ID);
    if (XST_SUCCESS != status) {
        return XST_FAILURE;
    }
    XGpio_SetDataDirection(&gGpioBlank, VBLANK, 1);
    XGpio_SetDataDirection(&gGpioBlank, CLR_VBLANK, 0);

    /* Initialize bitblt. */
    status = XBitblt_Initialize(&gBitbltInstance, XPAR_XBITBLT_0_DEVICE_ID);
    if (XST_SUCCESS != status) {
        return XST_FAILURE;
    }

    /* Initialize patblt. */
    status = XPatblt_Initialize(&gPatbltInstance, XPAR_XPATBLT_0_DEVICE_ID);
    if (XST_SUCCESS != status) {
        return XST_FAILURE;
    }

    /* Enable display. */
    wait_vblank();
    XGpio_DiscreteWrite(&gGpioAddrOn, DISP_ADDR, VRAM_START_ADDR);
    XGpio_DiscreteWrite(&gGpioAddrOn, DISP_ON, 1);

    /* Clear the display. */
    patblt(VRAM_START_ADDR, 0, 0, DISPLAY_WIDTH, DISPLAY_HEIGHT, 0x00000000);

    /* Draw boxes on the texture buffer. */
    patblt(TEXTURE_START_ADDR + PIXEL_OFFSET_SRC0*sizeof(uint32_t),  0,  0, BOX_WIDTH, BOX_HEIGHT, 0x00ff0000);
    patblt(TEXTURE_START_ADDR + PIXEL_OFFSET_SRC1*sizeof(uint32_t),  0,  0, BOX_WIDTH, BOX_HEIGHT, 0x000000ff);

    /* Copy the textures into the display. */
    bitblt(TEXTURE_START_ADDR + PIXEL_OFFSET_SRC0*sizeof(uint32_t), VRAM_START_ADDR + PIXEL_OFFSET_DST0*sizeof(uint32_t), VRAM_START_ADDR + PIXEL_OFFSET_DST0*sizeof(uint32_t), 255, BOX_WIDTH, BOX_HEIGHT);
    bitblt(TEXTURE_START_ADDR + PIXEL_OFFSET_SRC1*sizeof(uint32_t), VRAM_START_ADDR + PIXEL_OFFSET_DST1*sizeof(uint32_t), VRAM_START_ADDR + PIXEL_OFFSET_DST1*sizeof(uint32_t), 128, BOX_WIDTH, BOX_HEIGHT);

    usleep(static_cast<ULONG>(1000000));

    /* Disable display. */
    wait_vblank();
    XGpio_DiscreteWrite(&gGpioAddrOn, DISP_ON, 0);
    return XST_SUCCESS;
}
