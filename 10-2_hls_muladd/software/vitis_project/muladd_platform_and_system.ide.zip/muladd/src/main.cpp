#include <cstdlib>
#include <xil_printf.h>
#include <xparameters.h>
#include <xmuladd.h>

constexpr size_t ARRAY_LENGTH = 16;

XMuladd muladdInstance;

int main() {
    uint32_t a[ARRAY_LENGTH], b[ARRAY_LENGTH], sumProd_expected;

    /* Initialize muladd. */
    if (XMuladd_Initialize(&muladdInstance, XPAR_MULADD_0_DEVICE_ID) != XST_SUCCESS) {
        xil_printf("Error: muladd failed to initialize.\n");
        return XST_FAILURE;
    }

    /* Create the expected result. */
    sumProd_expected = 0;
    for (size_t i=0; i<ARRAY_LENGTH; i++) {
        a[i] = rand() & 0xffff;
        b[i] = rand() & 0xffff;
        sumProd_expected += a[i] * b[i];
        xil_printf("a[%2d] = %04x, b[%2d] = %04x, sumProd_expected = %08x\n", i, a[i], i, b[i], sumProd_expected);
    }

    /* Write arrays a and b via AXI ports. */
    XMuladd_Write_a_Words(&muladdInstance, 0, a, ARRAY_LENGTH);
    XMuladd_Write_b_Words(&muladdInstance, 0, b, ARRAY_LENGTH);

    /* Start the muladd module and wait until the result is available */
    XMuladd_Start(&muladdInstance);
    while (!XMuladd_IsDone(&muladdInstance)) {};

    /* Compare the result with the expected one. */
    {
        const uint32_t result = XMuladd_Get_return(&muladdInstance);
        if (sumProd_expected == result) {
            xil_printf("OK.\n");
        } else {
            xil_printf("NG: sumProd = %08x, expected = %08x\n", result, sumProd_expected);
        }
    }

    return XST_SUCCESS;
}
